﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMPAR_PAR
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;
            string linea;

            Console.Write("Ingrese numero entero: ");
            linea = Console.ReadLine();
            num = int.Parse(linea);

            if (num % 2 == 0)
            {
                Console.WriteLine("El numero: {0} ,es par", num);
            }
            else
            {
                Console.WriteLine("El numero: {0} ,es impar", num);
            }
            Console.ReadKey();
        }
    }
}
