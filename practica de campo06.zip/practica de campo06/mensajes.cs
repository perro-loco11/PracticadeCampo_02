﻿// LibreriaMensajes.cs
using System;

public static class LibreriaMensajes
{
    /// <summary>
    /// Función void para mostrar el menú principal del sistema.
    /// </summary>
    public static void MostrarMenu()
    {
        Console.WriteLine("\n--- SISTEMA DE REGISTRO DE NOTAS ---");
        Console.WriteLine("1. Registrar notas de los estudiantes.");
        Console.WriteLine("2. Mostrar todas las notas registradas.");
        Console.WriteLine("3. Buscar una nota por posición en el arreglo.");
        Console.WriteLine("4. Modificar una nota (por índice).");
        Console.WriteLine("5. Insertar una nueva nota en el arreglo (si hay espacio).");
        Console.WriteLine("6. Calcular el promedio de todas las notas.");
        Console.WriteLine("7. Salir.");
        Console.Write("Seleccione una opción (1-7): ");
    }

    /// <summary>
    /// Función void para imprimir mensajes generales al usuario.
    /// </summary>
    /// <param name="mensaje">El mensaje a mostrar.</param>
    public static void ImprimirMensaje(string mensaje)
    {
        Console.WriteLine($"\n[MENSAJE] {mensaje}");
    }
}