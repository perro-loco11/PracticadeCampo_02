﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practica_de_campo06
{
    internal class LibreriaMensajes
    {
    }
}
