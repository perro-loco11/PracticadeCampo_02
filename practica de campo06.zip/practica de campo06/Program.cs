﻿// Program.cs
using System;
using practica_de_campo06;

class Program
{
    private const int MAX_NOTAS = 30;

    static void Main(string[] args)
    {
        // El arreglo de 30 notas, inicializado a 0.0 por defecto
        double[] notas = new double[MAX_NOTAS];
        // Contador para saber cuántas posiciones están ocupadas
        int contadorNotas = 0;
        bool ejecutar = true;

        LibreriaMensajes.ImprimirMensaje("¡Bienvenido al Sistema de Registro de Notas! 📚");

        while (ejecutar)
        {
            try
            {
                LibreriaMensajes.MostrarMenu();
                if (!int.TryParse(Console.ReadLine(), out int opcion))
                {
                    LibreriaMensajes.ImprimirMensaje("Opción no válida. Ingrese un número del 1 al 7.");
                    continue;
                }

                switch (opcion)
                {
                    case 1: // 1. Registrar notas
                        Console.Write("Ingrese la nota a registrar (0.0 a 20.0): ");
                        if (double.TryParse(Console.ReadLine(), out double nuevaNota))
                        {
                            // Llama a la función con paso por REFERENCIA
                            LibreriaNotas.RegistrarNota(ref notas, nuevaNota, ref contadorNotas);
                        }
                        else
                        {
                            LibreriaMensajes.ImprimirMensaje("Entrada no válida para la nota.");
                        }
                        break;

                    case 2: // 2. Mostrar todas las notas
                        LibreriaNotas.MostrarTodasLasNotas(notas, contadorNotas);
                        break;

                    case 3: // 3. Buscar una nota por posición
                        Console.Write("Ingrese la posición (índice 0 a 29) a buscar: ");
                        if (int.TryParse(Console.ReadLine(), out int posBuscar))
                        {
                            // Llama a la función con paso por VALOR
                            double notaEncontrada = LibreriaNotas.BuscarNotaPorPosicion(notas, posBuscar);

                            if (notaEncontrada != -1.0)
                            {
                                LibreriaMensajes.ImprimirMensaje($"Nota en la posición {posBuscar}: {notaEncontrada:F2}");
                            }
                            else
                            {
                                LibreriaMensajes.ImprimirMensaje($"ERROR: Posición {posBuscar} inválida o sin nota registrada.");
                            }
                        }
                        else
                        {
                            LibreriaMensajes.ImprimirMensaje("Entrada no válida para la posición.");
                        }
                        break;

                    case 4: // 4. Modificar una nota
                        Console.Write("Ingrese el ÍNDICE (posición) de la nota a modificar: ");
                        if (int.TryParse(Console.ReadLine(), out int indiceModificar))
                        {
                            Console.Write("Ingrese la NUEVA nota (0.0 a 20.0): ");
                            if (double.TryParse(Console.ReadLine(), out double notaModificar))
                            {
                                // Llama a la función con paso por REFERENCIA
                                LibreriaNotas.ModificarNota(ref notas, indiceModificar, notaModificar);
                            }
                            else
                            {
                                LibreriaMensajes.ImprimirMensaje("Entrada no válida para la nueva nota.");
                            }
                        }
                        else
                        {
                            LibreriaMensajes.ImprimirMensaje("Entrada no válida para el índice.");
                        }
                        break;

                    case 5: // 5. Insertar una nueva nota
                        Console.Write($"Ingrese el ÍNDICE donde desea insertar la nota (0 a {contadorNotas}): ");
                        if (int.TryParse(Console.ReadLine(), out int indiceInsertar))
                        {
                            Console.Write("Ingrese la nota a insertar (0.0 a 20.0): ");
                            if (double.TryParse(Console.ReadLine(), out double notaAInsertar))
                            {
                                // Llama a la función con paso por REFERENCIA
                                LibreriaNotas.InsertarNota(ref notas, indiceInsertar, notaAInsertar, ref contadorNotas);
                            }
                            else
                            {
                                LibreriaMensajes.ImprimirMensaje("Entrada no válida para la nota a insertar.");
                            }
                        }
                        else
                        {
                            LibreriaMensajes.ImprimirMensaje("Entrada no válida para el índice de inserción.");
                        }
                        break;

                    case 6: // 6. Calcular el promedio
                        // Llama a la función con paso por VALOR
                        double promedio = LibreriaNotas.CalcularPromedio(notas);
                        LibreriaMensajes.ImprimirMensaje($"El promedio de todas las notas registradas es: {promedio:F2}");
                        break;

                    case 7: // 7. Salir
                        ejecutar = false;
                        LibreriaMensajes.ImprimirMensaje("Saliendo del sistema. ¡Hasta pronto! 👋");
                        break;

                    default:
                        LibreriaMensajes.ImprimirMensaje("Opción inválida. Por favor, seleccione un número del 1 al 7.");
                        break;
                }
            }
            catch (Exception ex)
            {
                // Manejo de errores genérico para evitar que el programa se detenga
                LibreriaMensajes.ImprimirMensaje($"Se produjo un error inesperado: {ex.Message}");
            }
        }
    }
}