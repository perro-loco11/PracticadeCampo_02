﻿// LibreriaNotas.cs
using System;
using System.Linq;
using practica_de_campo06;

public static class LibreriaNotas
{
    private const int MAX_NOTAS = 30;
    private const double NOTA_MIN = 0.0;
    private const double NOTA_MAX = 20.0;

    /// <summary>
    /// Función con retorno que cuenta cuántas notas válidas hay en el arreglo.
    /// (Usa paso de parámetros por valor)
    /// </summary>
    /// <param name="notas">El arreglo de notas.</param>
    /// <returns>La cantidad de notas registradas.</returns>
    public static int ContarNotasRegistradas(double[] notas)
    {
        // Se asume que las notas válidas son las diferentes a 0.0
        return notas.Count(n => n != 0.0);
    }

    /// <summary>
    /// Función con retorno que calcula el promedio de las notas registradas.
    /// (Usa paso de parámetros por valor)
    /// </summary>
    /// <param name="notas">El arreglo de notas.</param>
    /// <returns>El promedio de las notas, o 0.0 si no hay notas.</returns>
    public static double CalcularPromedio(double[] notas)
    {
        int count = ContarNotasRegistradas(notas);
        if (count == 0) return 0.0;

        double sum = notas.Sum();
        return sum / count;
    }

    /// <summary>
    /// Función con retorno que busca y devuelve una nota por su posición/índice.
    /// (Usa paso de parámetros por valor)
    /// </summary>
    /// <param name="notas">El arreglo de notas.</param>
    /// <param name="posicion">La posición a buscar (basada en índice 0).</param>
    /// <returns>La nota en esa posición o -1.0 si la posición es inválida.</returns>
    public static double BuscarNotaPorPosicion(double[] notas, int posicion)
    {
        if (posicion >= 0 && posicion < MAX_NOTAS && notas[posicion] != 0.0)
        {
            return notas[posicion];
        }
        return -1.0; // Valor especial para indicar que no se encontró
    }

    /// <summary>
    /// Registra una nueva nota al final del arreglo, si hay espacio.
    /// (Modifica el arreglo y el contador de notas por REFERENCIA)
    /// </summary>
    /// <param name="notas">El arreglo de notas (REFERENCIA).</param>
    /// <param name="nota">La nota a registrar.</param>
    /// <param name="contadorNotas">La cantidad actual de notas (REFERENCIA).</param>
    /// <returns>True si el registro fue exitoso, false si el arreglo está lleno o la nota es inválida.</returns>
    public static bool RegistrarNota(ref double[] notas, double nota, ref int contadorNotas)
    {
        if (contadorNotas >= MAX_NOTAS)
        {
            LibreriaMensajes.ImprimirMensaje("ERROR: El arreglo está lleno. No se puede registrar más notas.");
            return false;
        }

        if (nota < NOTA_MIN || nota > NOTA_MAX)
        {
            LibreriaMensajes.ImprimirMensaje($"ERROR: La nota debe estar entre {NOTA_MIN} y {NOTA_MAX}.");
            return false;
        }

        notas[contadorNotas] = nota;
        contadorNotas++;
        LibreriaMensajes.ImprimirMensaje($"Nota {nota:F2} registrada exitosamente en la posición {contadorNotas - 1}.");
        return true;
    }

    /// <summary>
    /// Modifica una nota existente en una posición específica.
    /// (Modifica el arreglo por REFERENCIA)
    /// </summary>
    /// <param name="notas">El arreglo de notas (REFERENCIA).</param>
    /// <param name="indice">El índice de la nota a modificar.</param>
    /// <param name="nuevaNota">La nueva nota a asignar.</param>
    /// <returns>True si la modificación fue exitosa, false si el índice es inválido o la nota es inválida.</returns>
    public static bool ModificarNota(ref double[] notas, int indice, double nuevaNota)
    {
        if (indice < 0 || indice >= MAX_NOTAS || notas[indice] == 0.0)
        {
            LibreriaMensajes.ImprimirMensaje("ERROR: Índice inválido o posición sin nota registrada para modificar.");
            return false;
        }

        if (nuevaNota < NOTA_MIN || nuevaNota > NOTA_MAX)
        {
            LibreriaMensajes.ImprimirMensaje($"ERROR: La nota debe estar entre {NOTA_MIN} y {NOTA_MAX}.");
            return false;
        }

        double notaAnterior = notas[indice];
        notas[indice] = nuevaNota;
        LibreriaMensajes.ImprimirMensaje($"Nota en el índice {indice} modificada de {notaAnterior:F2} a {nuevaNota:F2} exitosamente.");
        return true;
    }

    /// <summary>
    /// Inserta una nueva nota en una posición específica, desplazando los elementos siguientes.
    /// (Modifica el arreglo y el contador de notas por REFERENCIA)
    /// </summary>
    /// <param name="notas">El arreglo de notas (REFERENCIA).</param>
    /// <param name="indice">El índice donde insertar la nota.</param>
    /// <param name="notaAInsertar">La nota a insertar.</param>
    /// <param name="contadorNotas">La cantidad actual de notas (REFERENCIA).</param>
    /// <returns>True si la inserción fue exitosa, false si el arreglo está lleno, el índice es inválido o la nota es inválida.</returns>
    public static bool InsertarNota(ref double[] notas, int indice, double notaAInsertar, ref int contadorNotas)
    {
        if (contadorNotas >= MAX_NOTAS)
        {
            LibreriaMensajes.ImprimirMensaje("ERROR: El arreglo está lleno. No se puede insertar una nueva nota.");
            return false;
        }

        if (indice < 0 || indice > contadorNotas)
        {
            LibreriaMensajes.ImprimirMensaje($"ERROR: Índice de inserción inválido. Debe estar entre 0 y {contadorNotas}.");
            return false;
        }

        if (notaAInsertar < NOTA_MIN || notaAInsertar > NOTA_MAX)
        {
            LibreriaMensajes.ImprimirMensaje($"ERROR: La nota debe estar entre {NOTA_MIN} y {NOTA_MAX}.");
            return false;
        }

        // Desplazar elementos a la derecha para hacer espacio
        for (int i = contadorNotas; i > indice; i--)
        {
            notas[i] = notas[i - 1];
        }

        // Insertar la nueva nota
        notas[indice] = notaAInsertar;
        contadorNotas++;
        LibreriaMensajes.ImprimirMensaje($"Nota {notaAInsertar:F2} insertada exitosamente en el índice {indice}.");
        return true;
    }

    /// <summary>
    /// Muestra todas las notas registradas actualmente.
    /// </summary>
    /// <param name="notas">El arreglo de notas.</param>
    /// <param name="contadorNotas">La cantidad de notas registradas.</param>
    public static void MostrarTodasLasNotas(double[] notas, int contadorNotas)
    {
        if (contadorNotas == 0)
        {
            LibreriaMensajes.ImprimirMensaje("No hay notas registradas para mostrar.");
            return;
        }

        Console.WriteLine("\n--- NOTAS REGISTRADAS ---");
        for (int i = 0; i < contadorNotas; i++)
        {
            // Usamos F2 para mostrar con dos decimales, como se solicita
            Console.WriteLine($"[Índice {i}]: {notas[i]:F2}");
        }
    }
}