﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{

        
        public class Calculadora
        {
            public static void Main(string[] args)
            {
                bool continuar = true;

                while (continuar)
                {
                    Console.Clear(); 
                    Console.WriteLine("-----------------------------");
                    Console.WriteLine("CALCULADORA");
                    Console.WriteLine("-----------------------------");

                    
                    double num1 = PedirNumero("Ingresa el primer número: ");

                    
                    double num2 = PedirNumero("Ingresa el segundo número: ");

                    
                    Console.WriteLine("\nSelecciona la operación a realizar:");
                    Console.WriteLine("1 - Suma (+)");
                    Console.WriteLine("2 - Resta (-)");
                    Console.WriteLine("3 - Multiplicación (*)");
                    Console.WriteLine("4 - División (/)");
                    Console.Write("Opción (1-4): ");
                    string operacion = Console.ReadLine();

                    double resultado = 0;
                    bool operacionValida = true;

                    
                    switch (operacion)
                    {
                        case "1":
                            resultado=num1 + num2;
                            break;
                        case "2":
                            resultado=num1 - num2;
                            break;
                        case "3":
                            resultado=num1 * num2;
                            break;
                        case "4":
                            
                            if (num2 != 0)
                            {
                                resultado=num1 / num2;
                            }
                            else
                            {
                                Console.WriteLine("\n¡Error! No se puede dividir por cero.");
                                operacionValida = false;
                            }
                            break;
                        default:
                            Console.WriteLine("\n¡Error! Opción de operación no válida.");
                            operacionValida = false;
                            break;
                    }

                    
                    if (operacionValida)
                    {
                        Console.WriteLine($"\nEl resultado es: {resultado:F2}");
                    }

                    
                    Console.Write("\n¿Deseas realizar otro cálculo? (s/n): ");
                    string respuesta = Console.ReadLine().ToLower();

                    if (respuesta != "s")
                    {
                        continuar = false;
                    }
                }

                Console.WriteLine("\nGracias por usar la calculadora. ¡Adiós!");
                Console.ReadKey(); 
            }

           
            public static double PedirNumero(string mensaje)
            {
                double numero;
                bool entradaValida = false;

                do
                {
                    Console.Write(mensaje);
                    
                    if (double.TryParse(Console.ReadLine(), out numero))
                    {
                        entradaValida = true;
                    }
                    else
                    {
                        Console.WriteLine("Entrada no válida. Por favor, ingresa un número real.");
                    }
                } while (!entradaValida);

                return numero;
            }
        }
    }
    

