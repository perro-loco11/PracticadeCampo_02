﻿// LibreriaMensajes.cs
using System;

namespace SistemaInventario
{
    public class LibreriaMensajes
    {
        // Función void 1: Saludo inicial
        public static void MostrarBienvenida() // Ejemplo de función void sin parámetros
        {
            Console.Clear();
            Console.WriteLine("*****************");
            Console.WriteLine("* SISTEMA DE GESTIÓN DE INVENTARIO DE TIENDA *");
            Console.WriteLine("*****************");
            Console.WriteLine("Bienvenido al sistema. Por favor, selecciona una opción.");
        }

        // Función void 2: Mostrar el menú
        public static void MostrarMenu() // Ejemplo de función void sin parámetros
        {
            Console.WriteLine("\n--- MENÚ PRINCIPAL ---");
            Console.WriteLine("1. Agregar producto al inventario.");
            Console.WriteLine("2. Consultar productos disponibles.");
            Console.WriteLine("3. Actualizar stock de un producto.");
            Console.WriteLine("4. Eliminar producto.");
            Console.WriteLine("5. Salir.");
            Console.Write("\nSeleccione una opción: ");
        }

        // Función void 3: Mostrar mensajes de estado
        public static void MostrarMensaje(string mensaje, bool esError) // Ejemplo de parámetro por valor
        {
            if (esError)
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Green;
            }
            Console.WriteLine($"\n[INFO] {mensaje}");
            Console.ResetColor();
            Console.WriteLine("Presiona una tecla para continuar...");
            Console.ReadKey();
        }
    }
}
