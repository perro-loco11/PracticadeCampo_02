﻿// LibreriaInventario.cs
using System;
using System.Linq; // Necesario para 'Where' o 'Any' si se usa LINQ

namespace SistemaInventario
{
    public class LibreriaInventario
    {
        // Variable Global: Array de Productos con un tamaño fijo de 10
        private const int MAX_PRODUCTOS = 10;
        private static Producto[] inventario = new Producto[MAX_PRODUCTOS];

        // Función con return 1: Contar productos (por valor)
        public static int ContarProductos(Producto[] inventarioActual)
        {
            int contador = 0;
            // Recorremos el array
            for (int i = 0; i < MAX_PRODUCTOS; i++)
            {
                if (inventarioActual[i].EsValido) // Solo contamos los que son válidos
                {
                    contador++;
                }
            }
            return contador;
        }

        // Función con return 2: Buscar producto (por valor)
        // Devuelve el índice del producto en el array o -1 si no se encuentra
        public static int BuscarProducto(int codigoBuscar) // Ejemplo de parámetro por valor
        {
            for (int i = 0; i < MAX_PRODUCTOS; i++)
            {
                // Solo buscamos en posiciones con un producto válido
                if (inventario[i].EsValido && inventario[i].Codigo == codigoBuscar)
                {
                    return i; // Retorna la posición (índice)
                }
            }
            return -1; // No encontrado
        }

        // Función con return 3: Validar stock (por valor)
        public static bool ValidarStock(int stock)
        {
            // El stock debe ser mayor o igual a cero (ejemplo de validación)
            return stock >= 0;
        }

        // Función de gestión: Agregar producto
        public static void AgregarProducto(int codigo, string nombre, int stockInicial)
        {
            int totalProductos = ContarProductos(inventario);

            if (totalProductos >= MAX_PRODUCTOS)
            {
                LibreriaMensajes.MostrarMensaje("Inventario lleno. No se puede agregar más productos.", true);
                return;
            }

            if (BuscarProducto(codigo) != -1)
            {
                LibreriaMensajes.MostrarMensaje($"El producto con código {codigo} ya existe.", true);
                return;
            }

            // Buscamos la primera posición libre (donde EsValido es false)
            for (int i = 0; i < MAX_PRODUCTOS; i++)
            {
                if (!inventario[i].EsValido)
                {
                    inventario[i].Codigo = codigo;
                    inventario[i].Nombre = nombre;
                    inventario[i].Stock = stockInicial;
                    inventario[i].EsValido = true;
                    LibreriaMensajes.MostrarMensaje("Producto agregado correctamente.", false);
                    return;
                }
            }
        }

        // Función de gestión: Mostrar/Listar productos
        public static void ListarProductos() // Cumple con ser una función void para listar
        {
            if (ContarProductos(inventario) == 0)
            {
                LibreriaMensajes.MostrarMensaje("El inventario está vacío.", true);
                return;
            }

            Console.WriteLine("\n--------------------------------------------------");
            Console.WriteLine("| CÓDIGO | NOMBRE                  | STOCK  |");
            Console.WriteLine("--------------------------------------------------");

            for (int i = 0; i < MAX_PRODUCTOS; i++)
            {
                if (inventario[i].EsValido)
                {
                    // Formato para que la impresión sea ordenada
                    Console.WriteLine($"| {inventario[i].Codigo,-6} | {inventario[i].Nombre,-23} | {inventario[i].Stock,-6} |");
                }
            }
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine($"Total de productos registrados: {ContarProductos(inventario)}");
        }

        // Función de gestión: Actualizar Stock (por referencia)
        public static void ActualizarStock(int codigo, ref int nuevoStock) // Ejemplo de parámetro por referencia (ref)
        {
            int indice = BuscarProducto(codigo);

            if (indice == -1)
            {
                LibreriaMensajes.MostrarMensaje($"Producto con código {codigo} no encontrado.", true);
                return;
            }

            // El valor 'nuevoStock' que se pasa por referencia se usa para actualizar el stock del inventario
            inventario[indice].Stock = nuevoStock;
            LibreriaMensajes.MostrarMensaje($"Stock del producto '{inventario[indice].Nombre}' actualizado a {inventario[indice].Stock}.", false);
        }

        // Función de gestión: Eliminar producto
        public static void EliminarProducto(int codigo)
        {
            int indice = BuscarProducto(codigo);

            if (indice == -1)
            {
                LibreriaMensajes.MostrarMensaje($"Producto con código {codigo} no encontrado.", true);
                return;
            }

            // Para "eliminar" en un array fijo, simplemente invalidamos la entrada
            // y limpiamos los datos (opcional, pero buena práctica).
            inventario[indice].Codigo = 0;
            inventario[indice].Nombre = string.Empty;
            inventario[indice].Stock = 0;
            inventario[indice].EsValido = false;

            LibreriaMensajes.MostrarMensaje($"Producto '{codigo}' eliminado correctamente.", false);
        }
    }
}
