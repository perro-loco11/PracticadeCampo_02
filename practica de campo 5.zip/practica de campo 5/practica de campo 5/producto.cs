﻿// Producto.cs
using System;

namespace SistemaInventario
{
    // Usamos 'struct' para tipos de datos pequeños y centrados en datos
    // para cumplir con los requisitos básicos.
    public struct Producto
    {
        public int Codigo;
        public string Nombre;
        public int Stock;
        // La propiedad 'EsValido' nos ayuda a determinar si la posición 
        // del array tiene un producto o está libre.
        public bool EsValido;
    }
}
