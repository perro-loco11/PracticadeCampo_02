﻿// Program.cs
using System;

namespace SistemaInventario
{
    class Program
    {
        static void Main(string[] args)
        {
            LibreriaMensajes.MostrarBienvenida();

            bool continuar = true;
            while (continuar)
            {
                LibreriaMensajes.MostrarMenu();
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1": // Agregar producto
                        try
                        {
                            Console.Write("Ingrese código del producto: ");
                            int codigo = int.Parse(Console.ReadLine()); // Parámetro por valor
                            Console.Write("Ingrese nombre del producto: ");
                            string nombre = Console.ReadLine(); // Parámetro por valor
                            Console.Write("Ingrese stock inicial: ");
                            int stockInicial = int.Parse(Console.ReadLine()); // Parámetro por valor

                            if (LibreriaInventario.ValidarStock(stockInicial))
                            {
                                LibreriaInventario.AgregarProducto(codigo, nombre, stockInicial);
                            }
                            else
                            {
                                LibreriaMensajes.MostrarMensaje("Error: El stock inicial no puede ser negativo.", true);
                            }
                        }
                        catch (FormatException)
                        {
                            LibreriaMensajes.MostrarMensaje("Error: Entrada inválida. Asegúrese de ingresar números para código y stock.", true);
                        }
                        break;
                    case "2": // Consultar productos disponibles
                        LibreriaInventario.ListarProductos();
                        LibreriaMensajes.MostrarMensaje("Consulta finalizada.", false);
                        break;
                    case "3": // Actualizar stock de un producto
                        try
                        {
                            Console.Write("Ingrese código del producto a actualizar: ");
                            int codigo = int.Parse(Console.ReadLine()); // Parámetro por valor
                            Console.Write("Ingrese el nuevo stock: ");
                            int nuevoStock = int.Parse(Console.ReadLine());

                            if (LibreriaInventario.ValidarStock(nuevoStock))
                            {
                                // Uso de 'ref' para pasar el valor y permitir a la función modificarlo directamente
                                LibreriaInventario.ActualizarStock(codigo, ref nuevoStock);
                            }
                            else
                            {
                                LibreriaMensajes.MostrarMensaje("Error: El nuevo stock no puede ser negativo.", true);
                            }
                        }
                        catch (FormatException)
                        {
                            LibreriaMensajes.MostrarMensaje("Error: Entrada inválida. Asegúrese de ingresar números.", true);
                        }
                        break;
                    case "4": // Eliminar producto
                        try
                        {
                            Console.Write("Ingrese código del producto a eliminar: ");
                            int codigo = int.Parse(Console.ReadLine()); // Parámetro por valor
                            LibreriaInventario.EliminarProducto(codigo);
                        }
                        catch (FormatException)
                        {
                            LibreriaMensajes.MostrarMensaje("Error: Entrada inválida. Ingrese un número para el código.", true);
                        }
                        break;
                    case "5": // Salir
                        continuar = false;
                        LibreriaMensajes.MostrarMensaje("Gracias por usar el sistema. ¡Adiós!", false);
                        break;
                    default:
                        LibreriaMensajes.MostrarMensaje("Opción no válida. Intente de nuevo.", true);
                        break;
                }
            }
        }
    }
}
