﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace descuento_de_compra
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Variables
            double montoCompra, descuento, totalPagar;

            // Constantes
            const double PORCENTAJE_DESCUENTO = 0.15; // 15%
            const double MONTO_MINIMO = 200; // S/ 200

            Console.WriteLine("=== SISTEMA DE DESCUENTO EN COMPRAS ===\n");

            // Solicitar el monto de la compra
            Console.Write("Ingrese el monto de la compra (S/): ");
            montoCompra = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("\n--- DETALLE DE LA COMPRA ---");

            // Mostrar subtotal
            Console.WriteLine($"Subtotal: S/ {montoCompra:F2}");

            // Verificar si aplica descuento
            if (montoCompra > MONTO_MINIMO)
            {
                // Calcular descuento
                descuento = montoCompra * PORCENTAJE_DESCUENTO;
                totalPagar = montoCompra - descuento;

                Console.WriteLine($"Descuento aplicado (15%): S/ {descuento:F2}");
                Console.WriteLine($"¡Increible! Su compra supera los S/ {MONTO_MINIMO:F2}");
            }
            else
            {
                // No hay descuento
                descuento = 0;
                totalPagar = montoCompra;

                Console.WriteLine($"Descuento aplicado: S/ {descuento:F2}");
                Console.WriteLine($"Para obtener 15% de descuento, su compra debe superar S/ {MONTO_MINIMO:F2}");
            }

            // Mostrar total a pagar
            Console.WriteLine($"\nTOTAL A PAGAR: S/ {totalPagar:F2}");

            // Mostrar ahorro si hay descuento
            if (descuento > 0)
            {
                Console.WriteLine($"Usted se ahorró: S/ {descuento:F2}");
            }

            Console.WriteLine("\nPresione cualquier tecla para salir...");
            Console.ReadKey();
        }
    }
}
