﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace promedio_de_notas_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nota1, nota2, nota3, promedio;

            Console.WriteLine("=== CALCULADORA DE PROMEDIO DE NOTAS ===\n");

            // Solicitar las tres notas al usuario
            Console.Write("Ingrese la primera nota: ");
            nota1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese la segunda nota: ");
            nota2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese la tercera nota: ");
            nota3 = Convert.ToDouble(Console.ReadLine());

            // Calcular el promedio
            promedio = (nota1 + nota2 + nota3) / 3;

            // Mostrar el promedio con 2 decimales
            Console.WriteLine($"\nPromedio: {promedio:F2}");

            // Determinar si está aprobado o desaprobado
            if (promedio >= 13)
            {
                Console.WriteLine("Estado: APROBADO");
            }
            else
            {
                Console.WriteLine("Estado: DESAPROBADO");
            }

            Console.WriteLine("\nPresione cualquier tecla para salir...");
            Console.ReadKey();
        }
    }
}
